#include <iostream>
using namespace std;

int main ()
{
    int n1, n2, n3;
    cout<<"Ingrese tres numeros diferentes: "; cin>>n1>>n2>>n3;
    

    int sum, prod, mayor, menor, prom;

    sum=n1+n2+n3;
    prod=n1*n2*n3;
    prom=n1*n2*n3/3;
    
    cout<<"La suma de estos numero es: "<<sum<<endl;
    cout<<"El producto de estos numeroes es: "<<prod<<endl;   
    cout<<"El promedio de estos numero es: "<<prom<<endl;

    int min = n1;
    int max = n1;

    if(n1<n2 && n1<n3)
        min=n1;
    if(n2<n1 && n2<n3)
        min=n2;
    if(n3<n1 && n3<n2)
        min=n3;
    if(n1>n2 && n1>n3)
        max=n1;
    if(n2>n1 && n2>n3)
        max=n2;
    if(n3>n1 && n3>n2)
        max=n3;

   cout<<"El numero menor es: "<<min<<endl;
   cout<<"El numero mayor es: "<<max<<endl;


}