#include <iostream>
using namespace std;

int main () {
    
    int area1, area2, area3, area4, area5, vol1, vol2, vol3, vol4, vol5;
    int n1=0, n2=1, n3=2, n4=3, n5=4;

    area1=6*(n1*n1);
    area2=6*(n2*n2);
    area3=6*(n3*n3);
    area4=6*(n4*n4);
    area5=6*(n5*n5);

    vol1=n1*n1*n1;
    vol2=n2*n2*n2;
    vol3=n3*n3*n3;
    vol4=n4*n4*n4;
    vol5=n5*n5*n5;


    cout<<"Logitud de la cara del cubo (cm): \t El area de la superficie del cubo (cm^2): \t El volumen del cubo (cm^3): "<<endl;
    cout<<n1<<"\t\t\t\t\t "<<area1<<"\t\t\t\t\t\t "<<vol1<<"\n"<<n2<<"\t\t\t\t\t "<<area2<<"\t\t\t\t\t\t "<<vol2
    <<"\n"<<n3<<"\t\t\t\t\t "<<area3<<"\t\t\t\t\t\t "<<vol3<<"\n"<<n4<<"\t\t\t\t\t "<<area4<<"\t\t\t\t\t\t "<<vol4
    <<"\n"<<n5<<"\t\t\t\t\t "<<area5<<"\t\t\t\t\t\t "<<vol5;
}
