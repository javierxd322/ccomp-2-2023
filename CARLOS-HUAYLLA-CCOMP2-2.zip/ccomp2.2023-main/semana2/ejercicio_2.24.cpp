#include <iostream>
using namespace std;

int main () {
    
    int a,b,suma;
    
    cout << "Ingrese dos numeros: " << endl;
    cin >> a >> b;
    
    suma = a+b;

    if ( suma %2 == 0)   
    {
        cout << "La suma es par: "<<suma<<endl;
        
    }
        else 
        cout << "La suma es impar: "<<suma<<endl;

    return 0;
}