#include <iostream>
using namespace std;

int main() {
  int numero, n1, n2, n3, n4;

  cout << "Introduce un número de 4 cifras: ";
  cin >> numero;

  n1 = numero / 1000;
  n2 = (numero / 100) % 10;
  n3 = (numero / 10) % 10;
  n4 = numero % 10;

  cout << "Número invertido: " << n4 << n3 << n2 << n1 << endl;

  return 0;
}