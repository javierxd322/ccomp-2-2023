#include <iostream>
using namespace std;

int main ()
{
    float rad; 
    float pi=3.1416;

    cout<<"Ingrese un numero: ";
    cin>>rad;
    float diametro, circun, area;
    
    diametro = (rad)*2;
    circun = pi*diametro;
    area = pi*(rad*rad);

    cout<<"El radio es: "<<rad<<endl;
    cout<<"El diametro es: "<<diametro<<endl;
    cout<<"La circunferencia es: "<<circun<<endl;
    cout<<"El area es: "<<area<<endl;
    
    
    return 0;

}